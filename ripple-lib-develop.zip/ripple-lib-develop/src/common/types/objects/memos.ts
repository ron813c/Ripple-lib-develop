
export type Memo = {
  type?: string,
  format?: string,
  data?: string
}
