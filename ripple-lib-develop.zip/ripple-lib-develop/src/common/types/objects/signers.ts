export interface SignerEntry {
  Account: string,
  SignerWeight: number
}
