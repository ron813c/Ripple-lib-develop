'use strict';

function getAddress() {
  return 'rQDhz2ZNXmhxzCYwxU6qAbdxsHA4HV45Y2';
}

function getSecret() {
  return 'shK6YXzwYfnFVn3YZSaMh5zuAddKx';
}

module.exports = {
  getAddress,
  getSecret
};
