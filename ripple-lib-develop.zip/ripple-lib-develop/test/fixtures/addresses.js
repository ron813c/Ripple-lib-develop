'use strict';
module.exports = {
  ACCOUNT: 'r9cZA1mLK5R5Am25ArfXFmqgNwjZgnfk59',
  OTHER_ACCOUNT: 'rpZc4mVfWUif9CRoHRKKcmhu1nx2xktxBo',
  THIRD_ACCOUNT: 'rwBYyfufTzk77zUSKEu4MvixfarC35av1J',
  FOURTH_ACCOUNT: 'rJnZ4YHCUsHvQu7R6mZohevKJDHFzVD6Zr',
  ISSUER: 'rMH4UxPrbuMa1spCBR98hLLyNJp4d8p4tM',
  NOTFOUND: 'rajTAg3hon5Lcu1RxQQPxTgHvqfhc1EaUS',
  SECRET: 'shsWGZcmZz6YsWWmcnpfr6fLTdtFV',
  SOURCE_LOW_FUNDS: 'rhVgDEfS1r1fLyRUZCpab4TdowZcAJwHy2'
};
